$(document).ready(function() {
  $("a.js-all-shows").on("click", function(e) {
    alert("You click on all shows");
    e.preventDefault();
  });

});
